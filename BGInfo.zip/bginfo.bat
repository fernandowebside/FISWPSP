@echo off
C:\Windows\BGInfo\Bginfo.exe /accepteula C:\Windows\BGInfo\config_bg.bgi /timer:0 /silent
