@echo off
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v BGinfo /t reg_sz /d "\"C:\Windows\BGInfo\bginfo.bat\"" /f
