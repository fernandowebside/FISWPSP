@echo off
C:\Windows\BGInfo\Bginfo.exe C:\Windows\BGInfo\config_bg.bgi /timer:0 /accepteula@echo off
C:\Windows\BGInfo\Bginfo.exe C:\Windows\BGInfo\config_bg.bgi /timer:0 /accepteula